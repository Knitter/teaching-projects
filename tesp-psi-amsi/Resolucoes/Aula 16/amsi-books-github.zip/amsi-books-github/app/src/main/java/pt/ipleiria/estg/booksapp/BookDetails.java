package pt.ipleiria.estg.booksapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import pt.ipleiria.estg.booksapp.models.Book;
import pt.ipleiria.estg.booksapp.models.DataAccessHelper;

public class BookDetails extends AppCompatActivity {

    private long bookId;
    private Book book;
    private DataAccessHelper dbHelper;

    private ImageView ivAcBookDetailsCover;
    private TextView tvAcBookDetailsTitle;
    private TextView tvAcBookDetailsSeries;
    private TextView tvAcBookDetailsAuthor;
    private TextView tvAcBookDetailsISBN;
    private TextView tvAcBookDetailsYear;
    private TextView tvAcBookDetailsRating;
    private TextView tvAcBookDetailsSynopse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ac_bookdetails);

        Toolbar toolbar = (Toolbar) findViewById(R.id.tbAcBookDetailsToolbar);
        setSupportActionBar(toolbar);

        dbHelper = new DataAccessHelper(this);

        bookId = getIntent().getLongExtra("bookId", -1);

        ivAcBookDetailsCover = (ImageView) findViewById(R.id.ivAcBookDetailsCover);
        tvAcBookDetailsTitle = (TextView) findViewById(R.id.tvAcBookDetailsTitle);
        tvAcBookDetailsSeries = (TextView) findViewById(R.id.tvAcBookDetailsSeries);
        tvAcBookDetailsAuthor = (TextView) findViewById(R.id.tvAcBookDetailsAuthor);
        tvAcBookDetailsISBN = (TextView) findViewById(R.id.tvAcBookDetailsISBN);
        tvAcBookDetailsYear = (TextView) findViewById(R.id.tvAcBookDetailsYear);
        tvAcBookDetailsRating = (TextView) findViewById(R.id.tvAcBookDetailsRating);
        tvAcBookDetailsSynopse = (TextView) findViewById(R.id.tvAcBookDetailsSynopse);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.details_toolbar, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.mi_bookdetails_edit) {
            Intent i = new Intent("pt.ipleiria.estg.booksapp.BOOKFORM");
            i.putExtra("bookId", bookId);

            startActivity(i);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (bookId > -1) {
            book = dbHelper.findBook(bookId);

            ivAcBookDetailsCover.setImageResource(book.getCover());
            tvAcBookDetailsTitle.setText(book.getTitle());
            tvAcBookDetailsSeries.setText(book.getSeries());
            tvAcBookDetailsAuthor.setText(book.getAuthor());
            tvAcBookDetailsISBN.setText(book.getIsbn13());
            tvAcBookDetailsYear.setText(book.getYear());
            tvAcBookDetailsRating.setText("" + book.getRating());
            tvAcBookDetailsSynopse.setText(book.getSynopse());
        }
    }
}
