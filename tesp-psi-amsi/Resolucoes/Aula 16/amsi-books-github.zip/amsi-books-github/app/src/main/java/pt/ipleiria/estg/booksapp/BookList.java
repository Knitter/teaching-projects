package pt.ipleiria.estg.booksapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import pt.ipleiria.estg.booksapp.adapters.BookListItemAdapter;
import pt.ipleiria.estg.booksapp.models.DataAccessHelper;

public class BookList extends AppCompatActivity {

    private ListView lvAcBookListBooks;
    private DataAccessHelper dbHelper;
    private BookListItemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ac_booklist);

        // Configuração da toolbar como actionbar desta atividade. É necessário carregar a toolbar como fazemos com os
        // restantes componentes (usando findViewById) e depois definir a nossa toolbar como actiobar da atividade com
        // o método setSupportActionBar.
        Toolbar toolbar = (Toolbar) findViewById(R.id.tbAcBookListToolbar);
        setSupportActionBar(toolbar);

        // Instanciar o nosso helper de acesso à base de dados.
        dbHelper = new DataAccessHelper(this);
        adapter = new BookListItemAdapter(this, dbHelper.findAllBooks());

        lvAcBookListBooks = (ListView) findViewById(R.id.lvAcBookListBooks);
        lvAcBookListBooks.setAdapter(adapter);

        lvAcBookListBooks.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent("pt.ipleiria.estg.booksapp.BOOKDETAILS");

                // Como a posição na ListView é a mesma que na nossa lista de livros fornecida pela classe de dados
                // de teste, podemos passar diretamente a posição em que o utilizador tocou para identificar o livro
                // que foi selecionado.
                i.putExtra("bookId", adapter.getItemId(position));
                startActivity(i);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // carregar o XML e preencheer o objeto Menu com os elementos no nosso ficheiro toolbar.xml
        getMenuInflater().inflate(R.menu.toolbar, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Para tratar a resposta aos toques do utilizador podemos usaro ID do elemento definido no XML e comparar em
        // código para determinar que ação vamos tomar.

        // Neste caso estamos apenas a abrir novas atividades com base no ID do elemento escolhido.
        int id = item.getItemId();
        if (id == R.id.mi_booklist_gallery) {
            Intent i = new Intent("pt.ipleiria.estg.booksapp.GALLERY");
            startActivity(i);

            return true;
        }

        if (id == R.id.mi_booklist_about) {
            Intent i = new Intent("pt.ipleiria.estg.booksapp.ABOUT");
            startActivity(i);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
