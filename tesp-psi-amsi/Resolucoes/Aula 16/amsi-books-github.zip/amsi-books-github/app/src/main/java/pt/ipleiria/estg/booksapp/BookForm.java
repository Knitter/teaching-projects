package pt.ipleiria.estg.booksapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.RatingBar;

import pt.ipleiria.estg.booksapp.models.Book;
import pt.ipleiria.estg.booksapp.models.DataAccessHelper;

public class BookForm extends AppCompatActivity {

    private long bookId;
    private Book book;
    private DataAccessHelper dbHelper;

    private EditText etAcBookFormTitle;
    private EditText etAcBookFormSeries;
    private EditText etAcBookFormAuthor;
    private EditText etAcBookFormISBN;
    private EditText etAcBookFormYear;
    private RatingBar rbAcBookFormRating;
    private EditText etAcBookFormSynopse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ac_bookform);

        Toolbar toolbar = (Toolbar) findViewById(R.id.tbAcBookFormToolbar);
        setSupportActionBar(toolbar);

        dbHelper = new DataAccessHelper(this);

        etAcBookFormTitle = (EditText) findViewById(R.id.etAcBookFormTitle);
        etAcBookFormSeries = (EditText) findViewById(R.id.etAcBookFormSeries);
        etAcBookFormAuthor = (EditText) findViewById(R.id.etAcBookFormAuthor);
        etAcBookFormISBN = (EditText) findViewById(R.id.etAcBookFormISBN);
        etAcBookFormYear = (EditText) findViewById(R.id.etAcBookFormYear);
        rbAcBookFormRating = (RatingBar) findViewById(R.id.rbAcBookFormRating);
        etAcBookFormSynopse = (EditText) findViewById(R.id.etAcBookFormSynopse);

        bookId = getIntent().getLongExtra("bookId", -1);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.form_toolbar, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.mi_bookform_save) {

            // Se não existe um livro associado à atividade então é porque estamos a criar um novo livro em vez de
            // editarmos um livro existente.
            if (book == null) {

                // Não podemos passar uma imagem porque ainda estamos a usar drawables da pasta res e não temos como
                // colocar uma imagem em runtime nessa pasta.
                dbHelper.addBook(new Book(etAcBookFormTitle.getText().toString(),
                        etAcBookFormSeries.getText().toString(), etAcBookFormAuthor.getText().toString(),
                        etAcBookFormYear.getText().toString(), etAcBookFormISBN.getText().toString(),
                        etAcBookFormSynopse.getText().toString(), rbAcBookFormRating.getRating(), 0));

                return true;
            }

            // Se estamos a editar o livros, vamos apenas alterar os dados deste uma vez que estamos a manter sempre
            // a referência para a variável estática/global.
            book.setTitle(etAcBookFormTitle.getText().toString());
            book.setSeries(etAcBookFormSeries.getText().toString());
            book.setAuthor(etAcBookFormAuthor.getText().toString());
            book.setYear(etAcBookFormYear.getText().toString());
            book.setIsbn13(etAcBookFormISBN.getText().toString());
            book.setSynopse(etAcBookFormSynopse.getText().toString());
            book.setRating(rbAcBookFormRating.getRating());

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();

        etAcBookFormTitle.setText("");
        etAcBookFormSeries.setText("");
        etAcBookFormAuthor.setText("");
        etAcBookFormISBN.setText("");
        etAcBookFormYear.setText("");
        rbAcBookFormRating.setRating(0f);
        etAcBookFormSynopse.setText("");

        if (bookId > -1) {
            book = dbHelper.findBook(bookId);

            etAcBookFormTitle.setText(book.getTitle());
            etAcBookFormSeries.setText(book.getSeries());
            etAcBookFormAuthor.setText(book.getAuthor());
            etAcBookFormISBN.setText(book.getIsbn13());
            etAcBookFormYear.setText(book.getYear());
            rbAcBookFormRating.setRating(book.getRating());
            etAcBookFormSynopse.setText(book.getSynopse());
        }
    }
}
