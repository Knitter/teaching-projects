package pt.ipleiria.estg.booksapp.models;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

import pt.ipleiria.estg.booksapp.R;

public class DataAccessHelper extends SQLiteOpenHelper {

    private static final int DB_VERSION = 1;
    private static final String DB_NAME = "books";

    /**
     * @param context
     */
    public DataAccessHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createBookTable = "CREATE TABLE Book (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "title TEXT, " +
                "series TEXT, " +
                "author TEXT, " +
                "year TEXT, " +
                "isbn13 TEXT, " +
                "synopse TEXT, " +
                "rating FLOAT, " +
                "cover INTEGER" +
                ")";

        db.execSQL(createBookTable);

        // Dados de teste, apenas executado quando a base de dados é criada.
        // Será removido quando a aplicação estiver a base de dados em pleno.
        populateDatabase(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Implementação básica que serve para a versão atual mas que deverá ser atualizada à medida que a aplicação
        // for sendo corrigida.
        db.execSQL("DROP TABLE IF EXISTS Book");
        onCreate(db);
    }

    /**
     * @param book
     * @return
     */
    public boolean addBook(Book book) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("title", book.getTitle());
        values.put("series", book.getSeries());
        values.put("author", book.getAuthor());
        values.put("year", book.getYear());
        values.put("isbn13", book.getIsbn13());
        values.put("synopse", book.getSynopse());
        values.put("rating", book.getRating());
        values.put("cover", book.getCover());

        long id = db.insert("Book", null, values);
        if (id > -1) {
            book.setId(id);
            return true;
        }

        return false;
    }

    /**
     * @param bookId
     * @return
     */
    public Book removeBook(long bookId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("Book", "id = ?", new String[]{"" + bookId});

        return null;
    }

    /**
     * @param book
     * @return
     */
    public boolean saveBook(Book book) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("title", book.getTitle());
        values.put("series", book.getSeries());
        values.put("author", book.getAuthor());
        values.put("year", book.getYear());
        values.put("isbn13", book.getIsbn13());
        values.put("synopse", book.getSynopse());
        values.put("rating", book.getRating());

        return (db.update("Books", values, "id = ?", new String[]{"" + book.getId()}) > 0);
    }

    /**
     * @return
     */
    public List<Book> findAllBooks() {
        List<Book> books = new ArrayList<>();

        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Book", null);

        if (cursor.moveToFirst()) {
            do {
                books.add(new Book(cursor.getLong(0), cursor.getString(1), cursor.getString(2), cursor.getString(3),
                        cursor.getString(4), cursor.getString(5), cursor.getString(6), cursor.getFloat(7),
                        cursor.getInt(8)));

            } while (cursor.moveToNext());
        }

        return books;
    }

    /**
     * @param bookId
     * @return
     */
    public Book findBook(long bookId) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query("Book", null, "id = ?", new String[]{"" + bookId}, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            return new Book(cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4),
                    cursor.getString(5), cursor.getString(6), cursor.getFloat(7), cursor.getInt(8));
        }

        return null;
    }

    /**
     * Método usado para criar dados de teste e que deverá ser removido na próxima versão da aplicação.
     *
     * @param db
     */
    private void populateDatabase(SQLiteDatabase db) {

        Book[] data = {
                new Book("Among Thieves", "Tales of the Kin, #1", "Douglas Hulick", "2011", "9780330536202", "Drothe is a Nose, an informant who finds and takes care of trouble inside the criminal organization he's a part of. He also smuggles imperial relics on the side. When his boss sends him to Ten Ways to track down who's been leaning on his organization's people, Drothe discovers hints of a much bigger mystery.", 0.0f, R.drawable.amongthieves),
                new Book("Children of Dune", "Dune, #3", "Frank Herbert", "1987", "9780441104024", "The desert planet of Arrakis has begun to grow green and lush. The life-giving spice is abundant. The nine-year-old royal twins, possesing their father's supernatural powers, are being groomed as Messiahs.", 0.0f, R.drawable.childrenofdune),
                new Book("A Darkness At Sethanon", "The Riftwar Saga, #4", "Raymond E. Feist", "2007", "9780007229437", "An evil wind blows through Midkemia. Dark legions have risen up to crush the Kingdom of the Isles and enslave it to dire magics. The final battle between Order and Chaos is about to begin in the ruins of the city called Sethanon.", 0.0f, R.drawable.darknessatsethanon),
                new Book("Dune", "Dune, #1", "Frank Herbert", "2005", "9780441013593", "Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, who would become the mysterious man known as Muad'Dib. He would avenge the traitorous plot against his noble family--and would bring to fruition humankind's most ancient and unattainable dream.A stunning blend of adventure and mysticism, environmentalism and politics.", 0.0f, R.drawable.dune),
                new Book("Ender's Game", "The Ender Quintet, #1", "Orson Scott Card", "2013", "9780765370624", "Andrew \"Ender\" Wiggin thinks he is playing computer simulated war games; he is, in fact, engaged in something far more desperate. Ender may be the military genius Earth desperately needs in a war against an alien enemy seeking to destroy all human life. The only way to find out is to throw Ender into ever harsher training, to chip away and find the diamond inside, or destroy him utterly. Ender Wiggin is six years old when it begins. He will grow up fast.", 0.0f, R.drawable.endersgame),
                new Book("Magician", "The Riftwar Saga, #1 e #2", "Raymond E. Feist", "2009", "9780586217832", "At Crydee, a frontier outpost in the tranquil Kingdom of the Isles, an orphan boy, Pug, is apprenticed to a master magician – and the destinies of two worlds are changed forever.", 0.0f, R.drawable.magician),
                new Book("Silverthorn", "The Riftwar Saga, #3", "Raymond E. Feist", "2008", "9780007229420", "For nearly a year peace has reigned in the Kingdom of the Isles, but mischief is stirring again in the city of Krondor and new challenges await Prince Arutha when Jimmy the Hand - the youngest thief in the Guild of Mockers - stumbles upon a sinister Nighthawk poised to assassinate him.", 0.0f, R.drawable.silverthorn),
                new Book("Starbound", "Lightship Chronicles, #2", "Dave Bara", "2016", "9780091956424", "The Lightship H.M.S. Impulse is gone, sacrificed in a battle against First Empire ships. And though the fragile galactic alliance has survived the unexpected invasion, the Union forces might not prove victorious against a full onslaught by this legendary enemy", 0.0f, R.drawable.starbound),
                new Book("Tales of Heresy", "The Horus Heresy, #10", "Dan Abnett", "2009", "9781844166824", "When Horus the Warmaster rebelled against the Emperor, the ensuing civil war nearly destroyed the Imperium. War raged across galaxy, pitting Astartes against their battle-brothers in a struggle where death was the only victor.", 0.0f, R.drawable.talesofheresy),
                new Book("The Beating of His Wings", "The Left Hand of God #3", "Paul Hoffman", "2013", "9780718155223", "Since discovering that his brutal military training has been for one purpose—to destroy God’s greatest mistake, mankind itself—Cale has been hunted by the very man who made him into the Angel of Death: Pope Redeemer Bosco.", 0.0f, R.drawable.thebeatingofhiswings),
                new Book("The Last Four Things", "The Left Hand of God, #2", "Paul Hoffman", "2011", "9780718155216", "To the warrior-monks known as the Redeemers, who rule over massive armies of child slaves, \"the last four things\" represent the culmination of a faithful life. Death. Judgement. Heaven.", 0.0f, R.drawable.thelastfourthings),
                new Book("The Left Hand of God", "The Left Hand of God #1", "Paul Hoffman", "2010", "9780718155186", "The Sanctuary of the Redeemers is a vast and desolate place—a place without joy or hope. Most of its occupants were taken there as boys and for years have endured the brutal regime of the Lord Redeemers whose cruelty and violence have one singular purpose—to serve in the name of the One True Faith.", 0.0f, R.drawable.thelefthandofgod)
        };

        ContentValues values;
        for (Book book : data) {
            values = new ContentValues();

            values.put("title", book.getTitle());
            values.put("series", book.getSeries());
            values.put("author", book.getAuthor());
            values.put("year", book.getYear());
            values.put("isbn13", book.getIsbn13());
            values.put("synopse", book.getSynopse());
            values.put("rating", book.getRating());
            values.put("cover", book.getCover());

            db.insert("Book", null, values);
        }
    }
}
