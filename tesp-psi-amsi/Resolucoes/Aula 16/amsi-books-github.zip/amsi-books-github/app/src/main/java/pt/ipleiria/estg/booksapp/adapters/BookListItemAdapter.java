package pt.ipleiria.estg.booksapp.adapters;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import pt.ipleiria.estg.booksapp.R;
import pt.ipleiria.estg.booksapp.models.Book;

public class BookListItemAdapter extends BaseAdapter {

    private Context context;
    private List<Book> books;
    private LayoutInflater inflater;

    public BookListItemAdapter(Context context, List<Book> books) {
        this.context = context;
        this.books = books;
    }

    @Override
    public int getCount() {
        return (books != null ? books.size() : 0);
    }

    @Override
    public Object getItem(int position) {
        return books.get(position);
    }

    @Override
    public long getItemId(int position) {
        return books.get(position).getId();
    }

    @Override
    public View getView(int position, View reusedView, ViewGroup parent) {

        if (inflater == null) {

            // Um "inflater" não é criado diretamente em código pelo programador. Deve sim ser obtido a partir de um
            // contexto válido (uma Activity já criada) para que seja corretamente configurado para o tipo de
            // dispositivo.
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if (reusedView == null) {
            reusedView = inflater.inflate(R.layout.li_bookitem, null);
        }

        Book current = books.get(position);

        ((TextView) reusedView.findViewById(R.id.tvAcBookListBookTitle)).setText(current.getTitle());
        ((TextView) reusedView.findViewById(R.id.tvAcBookListBookAuthor)).setText(current.getAuthor());

        String ratingString = context.getResources().getString(R.string.it_booklist_rating);
        ((TextView) reusedView.findViewById(R.id.tvAcBookListBookRating)).setText(ratingString + " " + current.getRating());

        ((TextView) reusedView.findViewById(R.id.tvAcBookListBookYear)).setText(current.getYear());

        return reusedView;
    }

}
