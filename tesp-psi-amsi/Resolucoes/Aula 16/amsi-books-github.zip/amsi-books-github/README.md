Books
====

Books is a small Android based application for book cataloging/managing. It allows users to create, edit 
and list books they own, offering features to manage details such as the book's title, author, publication year 
ISBN and the book' synopse and cover image.

It will also access the API from another book cataloging software, allowing users access to both a local and 
a remote dabase.

This APP is being developed as part of the course of Acesso Móvel a Sistemas de Informação of the TeSP em 
Programação de Sistemas de Informação being lectured at Escola Superior de Tecnologia e Gestão, IPLeiria. Though 
it will be made a full functioning application, it is used for teaching Android development and may contain 
code that is written under the constraints of its main objective.
