package pt.ipleiria.estg.booksapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import pt.ipleiria.estg.booksapp.adapters.BookListItemAdapter;
import pt.ipleiria.estg.booksapp.models.ExampleData;

public class BookList extends AppCompatActivity {

    private ListView lvBookList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ac_booklist);

        Toolbar toolbar = (Toolbar) findViewById(R.id.tbAcBookListToolbar);
        setSupportActionBar(toolbar);

        lvBookList = (ListView) findViewById(R.id.lvAcBookListList);
        lvBookList.setAdapter(new BookListItemAdapter(this, ExampleData.getBooks()));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        if (id == R.id.mi_booklist_gallery) {
            Intent i = new Intent("pt.ipleiria.estg.booksapp.GALLERY");
            startActivity(i);

            return true;
        }

        if (id == R.id.mi_booklist_about) {
            Intent i = new Intent("pt.ipleiria.estg.booksapp.ABOUT");
            startActivity(i);

            return true;
        }

        return super.onOptionsItemSelected(item);

    }
}
