package pt.ipleiria.estg.booksapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import pt.ipleiria.estg.booksapp.adapters.BookListItemAdapter;
import pt.ipleiria.estg.booksapp.models.ExampleData;

public class BookList extends AppCompatActivity {

    private ListView lvBookList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ac_booklist);

        lvBookList = (ListView) findViewById(R.id.lvAcBookListList);
        lvBookList.setAdapter(new BookListItemAdapter(this, ExampleData.getBooks()));
    }
}
