package pt.ipleiria.estg.booksapp.models;

public class Book {
    public static final String FORMAT_HARDCOVER = "HC";
    public static final String FORMAT_PAPERBACK = "PB";

    private long id;
    private String title;
    private String plot;
    private String isbn;
    private String format;
    private int pageCount;
    private String publicationDate;
    private String addedOn;
    private String language;
    private String edition;
    private String publisher;
    private float rating;
    private boolean read;
    private String url;
    private String review;
    private String cover;
    private int order;
    private int copies;
    private Series series;
    private Author author;

    public Book(long id, String title, String plot, String isbn, String format, int pageCount, String publicationDate,
                String addedOn, String language, String edition, String publisher, float rating, boolean read,
                String url, String review, String cover, int order, int copies, Series series, Author author) {

        this.id = id;
        this.title = title;
        this.plot = plot;
        this.isbn = isbn;
        this.format = format;
        this.pageCount = pageCount;
        this.publicationDate = publicationDate;
        this.addedOn = addedOn;
        this.language = language;
        this.edition = edition;
        this.publisher = publisher;
        this.rating = rating;
        this.read = read;
        this.url = url;
        this.review = review;
        this.cover = cover;
        this.order = order;
        this.copies = copies;
        this.series = series;
        this.author = author;
    }

    public Book() {
        this(0, null, null, null, FORMAT_PAPERBACK, 0, null, null, null, null, null, 0.0f, false, null, null, null, 1,
                1, null, null);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPlot() {
        return plot;
    }

    public void setPlot(String plot) {
        this.plot = plot;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    public String getPublicationDate() {
        return publicationDate;
    }

    public void setPublicationDate(String publicationDate) {
        this.publicationDate = publicationDate;
    }

    public String getAddedOn() {
        return addedOn;
    }

    public void setAddedOn(String addedOn) {
        this.addedOn = addedOn;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getEdition() {
        return edition;
    }

    public void setEdition(String edition) {
        this.edition = edition;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public boolean isRead() {
        return read;
    }

    public void setRead(boolean read) {
        this.read = read;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public int getCopies() {
        return copies;
    }

    public void setCopies(int copies) {
        this.copies = copies;
    }

    public Series getSeries() {
        return series;
    }

    public void setSeries(Series series) {
        this.series = series;
    }

    public Author getAuthor() {
        return author;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        final Book other = (Book) obj;
        return other.id == this.id;
    }
}
