package pt.ipleiria.estg.booksapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

import pt.ipleiria.estg.booksapp.db.LocalCache;
import pt.ipleiria.estg.booksapp.models.Author;

public class AuthorDetails extends AppCompatActivity {

    private Author author;
    private LocalCache db;
    //
    private TextInputLayout tlAuthorName;
    private TextView etAuthorName;
    private TextView etAuthorSurname;
    private TextView etAuthorBiography;
    private TextInputLayout tlAuthorURL;
    private TextView etAuthorURL;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ac_authordetails);

        db = new LocalCache(this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.tb_authordetails_toolbar);
        setSupportActionBar(toolbar);

        AuthorFieldValidator validator = new AuthorFieldValidator();

        tlAuthorName = (TextInputLayout) findViewById(R.id.tl_author_name);
        etAuthorName = (TextView) findViewById(R.id.et_author_name);
        etAuthorName.addTextChangedListener(validator);

        etAuthorSurname = (TextView) findViewById(R.id.et_author_surname);
        etAuthorBiography = (TextView) findViewById(R.id.et_author_biography);
        tlAuthorURL = (TextInputLayout) findViewById(R.id.tl_author_url);
        etAuthorURL = (TextView) findViewById(R.id.et_author_url);
        etAuthorURL.addTextChangedListener(validator);

        etAuthorName.setText("");
        etAuthorSurname.setText("");
        etAuthorBiography.setText("");
        etAuthorURL.setText("");

        long authorId = getIntent().getLongExtra("authorId", -1);
        Intent i = getIntent();
        if (authorId > -1) {
            author = db.findAuthor(authorId);

            etAuthorName.setText(author.getName());
            etAuthorSurname.setText(author.getSurname());
            etAuthorBiography.setText(author.getBiography());
            etAuthorURL.setText(author.getUrl());
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu_save, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.mi_save_option) {
            saveAuthorDetails(false);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void saveAuthorDetails(boolean back) {
        final View view = getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

        if (back && author == null && etAuthorName.getText().toString().trim().isEmpty()) {
            return;
        }

        if (author == null) {
            author = new Author();
        }

        author.setName(etAuthorName.getText().toString().trim());
        author.setSurname(etAuthorSurname.getText().toString().trim());
        author.setBiography(etAuthorBiography.getText().toString().trim());
        author.setUrl(etAuthorURL.getText().toString().trim());

        boolean saved = db.save(author);
        if (!back) {
            if (saved) {
                Snackbar.make(findViewById(R.id.cl_ac_authordetails_root), R.string.ok_msg_authordetails_save, Snackbar.LENGTH_SHORT).show();
            } else {
                Snackbar.make(findViewById(R.id.cl_ac_authordetails_root), R.string.err_msg_authordetails_save, Snackbar.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onPause() {
        saveAuthorDetails(true);

        super.onPause();
    }

    @Override
    protected void onResume() {
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        super.onResume();
    }

    private class AuthorFieldValidator implements TextWatcher {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            final View v = getCurrentFocus();
            if (v != null) {
                final String value = ((TextView) v).getText().toString().trim();

                switch (v.getId()) {
                    case R.id.et_author_name:
                        if (value.isEmpty()) {
                            tlAuthorName.setError(getString(R.string.err_msg_author_name));
                            if (etAuthorName.requestFocus()) {
                                getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                            }

                            return;
                        }

                        tlAuthorName.setErrorEnabled(false);
                        break;

                    case R.id.et_author_url:
                        if (!value.isEmpty()) {
                            if (!Patterns.WEB_URL.matcher(value).matches()) {
                                tlAuthorURL.setError(getString(R.string.err_msg_author_url));
                                if (etAuthorURL.requestFocus()) {
                                    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                                }

                                return;
                            }
                        }

                        tlAuthorURL.setErrorEnabled(false);
                        break;
                }
            }
        }
    }
}
