package pt.ipleiria.estg.booksapp.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import pt.ipleiria.estg.booksapp.R;
import pt.ipleiria.estg.booksapp.adapters.BookListItemAdapter;
import pt.ipleiria.estg.booksapp.db.LocalCache;
import pt.ipleiria.estg.booksapp.models.Book;

public class BooksFragment extends Fragment {

    private LocalCache db;
    //
    private BookFragmentActionListener listener;
    private ListView lvFragmentBooks;
    private BookListItemAdapter adapter;
    private List<Book> books;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        db = new LocalCache(getActivity());
        books = db.findAllBooks();

        adapter = new BookListItemAdapter(getActivity(), books);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fg_books, container, false);

        lvFragmentBooks = (ListView) view.findViewById(R.id.lv_fragment_books);
        lvFragmentBooks.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                listener.bookSelected((Book) adapter.getItem(position));
            }
        });
        lvFragmentBooks.setAdapter(adapter);

        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.fab_fragment_newbook);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.creatingNewBook();
            }
        });

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            listener = (BookFragmentActionListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() + " must implement BookFragmentActionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();

        listener = null;
    }

    public void reloadData() {
        books = db.findAllBooks();
        adapter.setBooks(books);
    }

    public interface BookFragmentActionListener {

        public void creatingNewBook();

        public void bookSelected(Book book);
    }
}
