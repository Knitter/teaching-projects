package pt.ipleiria.estg.booksapp.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import pt.ipleiria.estg.booksapp.R;
import pt.ipleiria.estg.booksapp.adapters.AuthorListItemAdapter;
import pt.ipleiria.estg.booksapp.db.LocalCache;
import pt.ipleiria.estg.booksapp.models.Author;

public class AuthorsFragment extends Fragment {

    private LocalCache db;
    //
    private AuthorsFragment.AuthorFragmentActionListener listener;
    private ListView lvFragmentAuthors;
    private AuthorListItemAdapter adapter;
    private List<Author> authors;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        db = new LocalCache(getActivity());
        authors = db.findAllAuthors();

        adapter = new AuthorListItemAdapter(getActivity(), authors);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fg_authors, container, false);

        lvFragmentAuthors = (ListView) view.findViewById(R.id.lv_fragment_authors);
        lvFragmentAuthors.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                listener.authorSelected((Author) adapter.getItem(position));
            }
        });
        lvFragmentAuthors.setAdapter(adapter);

        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.fab_fragment_newauthor);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.creatingNewAuthor();
            }
        });

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            listener = (AuthorsFragment.AuthorFragmentActionListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() + " must implement AuthorFragmentActionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();

        listener = null;
    }

    public void reloadData() {
        authors = db.findAllAuthors();
        adapter.setAuthors(authors);
    }

    public interface AuthorFragmentActionListener {

        public void creatingNewAuthor();

        public void authorSelected(Author author);
    }
}
