package pt.ipleiria.estg.booksapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.os.Bundle;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import pt.ipleiria.estg.booksapp.db.LocalCache;
import pt.ipleiria.estg.booksapp.models.Author;
import pt.ipleiria.estg.booksapp.models.Book;
import pt.ipleiria.estg.booksapp.models.Series;

public class BookDetails extends AppCompatActivity {

    private Book book;
    private LocalCache db;
    //
    private List<Author> authors;
    private List<Series> series;
    //
    private TextInputLayout tlBookTitle;
    private TextView etBookTitle;
    private Spinner spBookAuthor;
    private Spinner spBookSeries;
    private TextView etBookOrder;
    private TextView etBookPlot;
    private TextView etBookISBN;
    private Spinner spBookFormat;
    private TextView etBookPageCount;
    private TextInputLayout tlBookPublicationDate;
    private TextView etBookPublicationDate;
    private TextView etBookLanguage;
    private TextView etBookEdition;
    private TextView etBookPublisher;
    private RatingBar rbBookRating;
    private CheckBox cbBookRead;
    private TextInputLayout tlBookURL;
    private TextView etBookURL;
    private TextView etBookReview;
    private TextView etBookCopies;
    //
    private String cover;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ac_bookdetails);

        db = new LocalCache(this);
        authors = db.findAllAuthors();
        series = db.findAllSeries();

        Toolbar toolbar = (Toolbar) findViewById(R.id.tb_bookdetails_toolbar);
        setSupportActionBar(toolbar);

        tlBookTitle = (TextInputLayout) findViewById(R.id.tl_book_title);
        etBookTitle = (TextView) findViewById(R.id.et_book_title);

        BookFieldValidator validator = new BookFieldValidator();
        etBookTitle.addTextChangedListener(validator);

        int i = 0;
        String[] authorsNames = new String[authors.size() + 1];
        authorsNames[i++] = getResources().getString(R.string.empty_authors_spinner);
        for (Author a : authors) {
            authorsNames[i++] = a.getName();
        }

        spBookAuthor = (Spinner) findViewById(R.id.sp_book_author);
        ArrayAdapter<String> authorSpinnerAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, authorsNames);
        authorSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBookAuthor.setAdapter(authorSpinnerAdapter);

        i = 0;
        String[] seriesNames = new String[series.size() + 1];
        seriesNames[i++] = getResources().getString(R.string.empty_series_spinner);
        for (Series s : series) {
            seriesNames[i++] = s.getName();
        }

        spBookSeries = (Spinner) findViewById(R.id.sp_book_series);
        ArrayAdapter<String> seriesSpinnerAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, seriesNames);
        seriesSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBookSeries.setAdapter(seriesSpinnerAdapter);

        etBookOrder = (TextView) findViewById(R.id.et_book_order);
        etBookPlot = (TextView) findViewById(R.id.et_book_plot);
        etBookISBN = (TextView) findViewById(R.id.et_book_isbn);
        spBookFormat = (Spinner) findViewById(R.id.sp_book_format);

        ArrayAdapter adapter2 = ArrayAdapter.createFromResource(this, R.array.book_formats,
                android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBookFormat.setAdapter(adapter2);

        etBookPageCount = (TextView) findViewById(R.id.et_book_page_count);
        tlBookPublicationDate = (TextInputLayout) findViewById(R.id.tl_book_publication_date);
        etBookPublicationDate = (TextView) findViewById(R.id.et_book_publication_date);
        etBookPublicationDate.addTextChangedListener(validator);

        etBookLanguage = (TextView) findViewById(R.id.et_book_language);
        etBookEdition = (TextView) findViewById(R.id.et_book_edition);
        etBookPublisher = (TextView) findViewById(R.id.et_book_publisher);
        rbBookRating = (RatingBar) findViewById(R.id.rb_book_rating);
        cbBookRead = (CheckBox) findViewById(R.id.cb_book_read);
        tlBookURL = (TextInputLayout) findViewById(R.id.tl_book_url);
        etBookURL = (TextView) findViewById(R.id.et_book_url);
        etBookURL.addTextChangedListener(validator);

        etBookReview = (TextView) findViewById(R.id.et_book_review);
        etBookCopies = (TextView) findViewById(R.id.et_book_copies);

        etBookTitle.setText("");
        etBookOrder.setText("");
        etBookPlot.setText("");
        etBookISBN.setText("");
        etBookPageCount.setText("");
        etBookPublicationDate.setText("");
        etBookLanguage.setText("");
        etBookEdition.setText("");
        etBookPublisher.setText("");
        rbBookRating.setRating(0.0f);
        cbBookRead.setChecked(false);
        etBookURL.setText("");
        etBookReview.setText("");
        etBookCopies.setText("");

        long bookId = getIntent().getLongExtra("bookId", -1);
        if (bookId > -1) {
            book = db.findBook(bookId);

            int pos = -1;
            etBookTitle.setText(book.getTitle());
            if (book.getAuthor() != null && authors.size() > 0) {
                pos = authors.indexOf(book.getAuthor());
                if (pos > -1) {
                    spBookAuthor.setSelection(pos + 1);
                }
            }

            if (book.getSeries() != null && series.size() > 0) {
                pos = series.indexOf(book.getSeries());
                if (pos > -1) {
                    spBookSeries.setSelection(pos + 1);
                }
            }

            if (book.getOrder() > 0) {
                etBookOrder.setText("" + book.getOrder());
            }

            etBookPlot.setText(book.getPlot());
            etBookISBN.setText(book.getIsbn());
            spBookFormat.setSelection((book.getFormat() == Book.FORMAT_HARDCOVER) ? 0 : 1);

            if (book.getPageCount() > 0) {
                etBookPageCount.setText("" + book.getPageCount());
            }

            etBookPublicationDate.setText(book.getPublicationDate());
            etBookLanguage.setText(book.getLanguage());
            etBookEdition.setText(book.getEdition());
            etBookPublisher.setText(book.getPublisher());
            rbBookRating.setRating(book.getRating());
            cbBookRead.setChecked(book.isRead());
            etBookURL.setText(book.getUrl());
            etBookReview.setText(book.getReview());

            if (book.getCopies() > 0) {
                etBookCopies.setText("" + book.getCopies());
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu_bookdetails, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        final int id = item.getItemId();
        if (id == R.id.mi_save_option) {
            saveBookDetails(false);
            return true;
        }

        if (id == R.id.mi_camera_option) {
            takeCoverPhoto();
        }

        return super.onOptionsItemSelected(item);
    }

    private void saveBookDetails(boolean back) {
        final View view = getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

        if (back && book == null && etBookTitle.getText().toString().trim().isEmpty()) {
            return;
        }

        if (book == null) {
            book = new Book();
            //TODO: ... book added date
            //book.setAddedOn();
        }

        if (authors.size() > 0) {
            book.setAuthor(null);
            if (spBookAuthor.getSelectedItemPosition() > 0) {
                book.setAuthor(authors.get(spBookAuthor.getSelectedItemPosition() - 1));
            }
        }

        if (authors.size() > 0) {
            book.setSeries(null);
            if (spBookSeries.getSelectedItemPosition() > 0) {
                book.setSeries(series.get(spBookSeries.getSelectedItemPosition() - 1));
            }
        }

        book.setTitle(etBookTitle.getText().toString().trim());
        book.setPlot(etBookPlot.getText().toString().trim());
        book.setIsbn(etBookISBN.getText().toString().trim());
        book.setFormat(spBookFormat.getSelectedItem().toString());
        String val = etBookPageCount.getText().toString().trim();
        if (!val.isEmpty()) {
            book.setPageCount(Integer.valueOf(etBookPageCount.getText().toString().trim()));
        }
        book.setPublicationDate(etBookPublicationDate.getText().toString().trim());
        book.setLanguage(etBookLanguage.getText().toString().trim());
        book.setEdition(etBookEdition.getText().toString().trim());
        book.setPublisher(etBookPublisher.getText().toString().trim());
        book.setRating(rbBookRating.getRating());
        book.setRead(cbBookRead.isChecked());
        book.setUrl(etBookURL.getText().toString().trim());
        book.setReview(etBookReview.getText().toString().trim());
        val = etBookOrder.getText().toString().trim();
        if (!val.isEmpty()) {
            book.setOrder(Integer.valueOf(val));
        }
        val = etBookCopies.getText().toString().trim();
        if(!val.isEmpty()) {
            book.setCopies(Integer.valueOf(val));
        }

        if (cover != null) {
            book.setCover(cover);
        }

        boolean saved = db.save(book);
        if (!back) {
            if (saved) {
                Snackbar.make(findViewById(R.id.cl_ac_bookdetails_root), R.string.ok_msg_bookdetails_save, Snackbar.LENGTH_SHORT).show();
            } else {
                Snackbar.make(findViewById(R.id.cl_ac_bookdetails_root), R.string.err_msg_bookdetails_save, Snackbar.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onPause() {
        saveBookDetails(true);

        super.onPause();
    }

    @Override
    protected void onResume() {
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        super.onResume();
    }

    private void takeCoverPhoto() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            String filename = "COVER_" + new SimpleDateFormat("yyyyMMdd.HHmmss").format(new Date()) + "_";
            File storage = getExternalFilesDir(Environment.DIRECTORY_PICTURES);

            File image = null;
            try {
                image = File.createTempFile(filename, ".jpg", storage);
                cover = image.getAbsolutePath();

                Uri uri = FileProvider.getUriForFile(this, "pt.ipleiria.estg.booksapp.coverfileprovider", image);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
                startActivityForResult(intent, 1);
            } catch (IOException ex) {
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == 0 && book != null && book.getCover() != null && !book.getCover().isEmpty()) {
            cover = null;
        }
    }

    private class BookFieldValidator implements TextWatcher {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            final View v = getCurrentFocus();
            if (v != null) {
                final String value = ((TextView) v).getText().toString().trim();

                switch (v.getId()) {
                    case R.id.et_book_title:
                        if (value.isEmpty()) {
                            tlBookTitle.setError(getString(R.string.err_msg_book_title));
                            if (etBookTitle.requestFocus()) {
                                getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                            }

                            return;
                        }

                        tlBookPublicationDate.setErrorEnabled(false);
                        break;

                    case R.id.et_book_publication_date:
                        if (!value.isEmpty()) {
                            tlBookPublicationDate.setError(getString(R.string.err_msg_book_publication_date));
                            //TODO: validar formato de data.
                        }

                        tlBookTitle.setErrorEnabled(false);
                        break;
                    case R.id.et_book_url:
                        if (!value.isEmpty()) {
                            if (!Patterns.WEB_URL.matcher(value).matches()) {
                                tlBookURL.setError(getString(R.string.err_msg_book_url));
                                if (etBookURL.requestFocus()) {
                                    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                                }

                                return;
                            }
                        }

                        tlBookURL.setErrorEnabled(false);
                        break;
                }
            }
        }
    }
}
