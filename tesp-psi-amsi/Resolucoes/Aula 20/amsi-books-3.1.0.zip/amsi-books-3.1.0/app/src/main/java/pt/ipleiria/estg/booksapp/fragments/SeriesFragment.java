package pt.ipleiria.estg.booksapp.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import pt.ipleiria.estg.booksapp.R;
import pt.ipleiria.estg.booksapp.adapters.SeriesListItemAdapter;
import pt.ipleiria.estg.booksapp.db.LocalCache;
import pt.ipleiria.estg.booksapp.models.Series;

public class SeriesFragment extends Fragment {

    private LocalCache db;
    //
    private SeriesFragment.SeriesFragmentActionListener listener;
    private ListView lvFragmentSeries;
    private SeriesListItemAdapter adapter;
    private List<Series> series;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        db = new LocalCache(getActivity());
        series = db.findAllSeries();

        adapter = new SeriesListItemAdapter(getActivity(), series);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fg_series, container, false);

        lvFragmentSeries = (ListView) view.findViewById(R.id.lv_fragment_series);
        lvFragmentSeries.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                listener.seriesSelected((Series) adapter.getItem(position));
            }
        });
        lvFragmentSeries.setAdapter(adapter);

        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.fab_fragment_newseries);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.creatingNewSeries();
            }
        });

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            listener = (SeriesFragment.SeriesFragmentActionListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() + " must implement SeriesFragmentActionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();

        listener = null;
    }

    public void reloadData() {
        series = db.findAllSeries();
        adapter.setSeries(series);
    }

    public interface SeriesFragmentActionListener {

        public void creatingNewSeries();

        public void seriesSelected(Series series);
    }
}
