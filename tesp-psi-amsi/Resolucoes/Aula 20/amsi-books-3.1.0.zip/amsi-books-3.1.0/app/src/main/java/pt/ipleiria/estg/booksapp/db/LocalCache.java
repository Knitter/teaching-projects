package pt.ipleiria.estg.booksapp.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

import pt.ipleiria.estg.booksapp.models.Author;
import pt.ipleiria.estg.booksapp.models.Book;
import pt.ipleiria.estg.booksapp.models.Series;

public class LocalCache extends SQLiteOpenHelper {

    private static final int DB_VERSION = 1;
    private static final String DB_NAME = "books";
    private static final String BOOK_TABLE_NAME = "Book";
    private static final String AUTHOR_TABLE_NAME = "Author";
    private static final String SERIES_TABLE_NAME = "Series";

    public LocalCache(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE IF NOT EXISTS " + AUTHOR_TABLE_NAME
                + " (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, surname TEXT, biography TEXT, url TEXT, photo TEXT) ;";
        db.execSQL(sql);

        sql = "CREATE TABLE IF NOT EXISTS " + SERIES_TABLE_NAME
                + " (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, bookCount INTEGER, ownCount, finished INTEGER) ;";
        db.execSQL(sql);

        sql = "; CREATE TABLE IF NOT EXISTS " + BOOK_TABLE_NAME
                + "(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, plot TEXT, isbn TEXT, format TEXT, "
                + "pageCount INTEGER, publicationDate TEXT, addedOn TEXT, language TEXT, edition TEXT, publisher TEXT, "
                + "rating FLOAT, read INTEGER, url TEXT, review TEXT, cover TEXT, seriesOrder INTEGER, copies INTEGER, "
                + "seriesId INTEGER, authorId INTEGER) ;";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + BOOK_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + SERIES_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + AUTHOR_TABLE_NAME);

        onCreate(db);
    }

    public boolean save(Author author) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("name", author.getName());
        values.put("surname", author.getSurname());
        values.put("biography", author.getBiography());
        values.put("photo", author.getPhoto());
        values.put("url", author.getUrl());

        if (author.getId() > 0) {
            return (db.update(AUTHOR_TABLE_NAME, values, "id = ?", new String[]{"" + author.getId()}) > 0);
        }

        long id = db.insert(AUTHOR_TABLE_NAME, null, values);
        if (id > -1) {
            author.setId(id);
            return true;
        }

        return false;
    }

    public boolean save(Series series) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("name", series.getName());
        values.put("bookCount", series.getBookCount());
        values.put("ownCount", series.getOwnCount());
        values.put("finished", series.isFinished() ? 1 : 0);

        if (series.getId() > 0) {
            return (db.update(SERIES_TABLE_NAME, values, "id = ?", new String[]{"" + series.getId()}) > 0);
        }

        long id = db.insert(SERIES_TABLE_NAME, null, values);
        if (id > -1) {
            series.setId(id);
            return true;
        }

        return false;
    }

    public boolean save(Book book) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("title", book.getTitle());
        values.put("plot", book.getPlot());
        values.put("isbn", book.getIsbn());
        values.put("format", book.getFormat());
        values.put("pageCount", book.getPageCount());
        values.put("publicationDate", book.getPublicationDate());
        values.put("addedOn", book.getAddedOn());
        values.put("language", book.getLanguage());
        values.put("edition", book.getEdition());
        values.put("publisher", book.getPublisher());
        values.put("rating", book.getRating());
        values.put("read", book.isRead() ? 1 : 0);
        values.put("url", book.getUrl());
        values.put("review", book.getReview());
        values.put("cover", book.getCover());
        values.put("seriesOrder", book.getOrder());
        values.put("copies", book.getCopies());

        Author author = book.getAuthor();
        if (author != null) {
            values.put("authorId", author.getId());
        }

        Series series = book.getSeries();
        if (author != null) {
            values.put("seriesId", series.getId());
        }

        if (book.getId() > 0) {
            return (db.update(BOOK_TABLE_NAME, values, "id = ?", new String[]{"" + book.getId()}) > 0);
        }

        long id = db.insert(BOOK_TABLE_NAME, null, values);
        if (id > -1) {
            book.setId(id);
            return true;
        }

        return false;
    }

    public boolean remove(Author author) {
        SQLiteDatabase db = getWritableDatabase();
        return (db.delete(AUTHOR_TABLE_NAME, "id = ?", new String[]{"" + author.getId()}) == 1);
    }

    public boolean remove(Series series) {
        SQLiteDatabase db = getWritableDatabase();
        return (db.delete(SERIES_TABLE_NAME, "id = ?", new String[]{"" + series.getId()}) == 1);

    }

    public boolean remove(long bookId) {
        SQLiteDatabase db = getWritableDatabase();
        return (db.delete(BOOK_TABLE_NAME, "id = ?", new String[]{"" + bookId}) == 1);
    }

    public Author findAuthor(long authorId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(AUTHOR_TABLE_NAME, null, "id = ?", new String[]{"" + authorId}, null, null, null, null);

        try {
            if (cursor != null && cursor.moveToFirst()) {
                return new Author(cursor.getLong(0), cursor.getString(1), cursor.getString(2), cursor.getString(3),
                        cursor.getString(4), cursor.getString(5));
            }
        } finally {
            cursor.close();
        }

        return null;
    }

    public Series findSeries(long seriesId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(SERIES_TABLE_NAME, null, "id = ?", new String[]{"" + seriesId}, null, null, null, null);

        try {
            if (cursor != null && cursor.moveToFirst()) {
                return new Series(cursor.getLong(0), cursor.getString(1), cursor.getInt(2), cursor.getInt(3),
                        (cursor.getInt(4) == 1));
            }
        } finally {
            cursor.close();
        }

        return null;
    }

    public Book findBook(long bookId) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(BOOK_TABLE_NAME, null, "id = ?", new String[]{"" + bookId}, null, null, null, null);

        try {
            if (cursor != null && cursor.moveToFirst()) {

                Series series = null;
                if (cursor.getLong(18) > 0) {
                    series = findSeries(cursor.getLong(18));
                }

                Author author = null;
                if (cursor.getLong(19) > 0) {
                    author = findAuthor(cursor.getInt(19));
                }

                return new Book(cursor.getLong(0), cursor.getString(1), cursor.getString(2), cursor.getString(3),
                        cursor.getString(4), cursor.getInt(5), cursor.getString(6), cursor.getString(7), cursor.getString(8),
                        cursor.getString(9), cursor.getString(10), cursor.getFloat(11), (cursor.getInt(12) == 1),
                        cursor.getString(13), cursor.getString(14), cursor.getString(15), cursor.getInt(16), cursor.getInt(17),
                        series, author);
            }
        } finally {
            cursor.close();
        }

        return null;
    }

    public List<Author> findAllAuthors() {
        List<Author> authors = new ArrayList<>();

        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + AUTHOR_TABLE_NAME + " ORDER BY name || surname", null);

        try {
            if (cursor.moveToFirst()) {
                do {
                    authors.add(new Author(cursor.getLong(0), cursor.getString(1), cursor.getString(2), cursor.getString(3),
                            cursor.getString(4), cursor.getString(5)));
                } while (cursor.moveToNext());
            }
        } finally {
            cursor.close();
        }

        return authors;
    }

    public List<Series> findAllSeries() {
        List<Series> series = new ArrayList<>();

        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + SERIES_TABLE_NAME + " ORDER BY name", null);

        try {
            if (cursor.moveToFirst()) {
                do {
                    series.add(new Series(cursor.getLong(0), cursor.getString(1), cursor.getInt(2), cursor.getInt(3),
                            (cursor.getInt(4) == 1)));
                } while (cursor.moveToNext());
            }
        } finally {
            cursor.close();
        }

        return series;
    }

    public List<Book> findAllBooks() {
        List<Book> books = new ArrayList<>();

        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + BOOK_TABLE_NAME, null);

        try {
            if (cursor.moveToFirst()) {
                Series series;
                Author author;

                do {
                    series = null;
                    if (cursor.getLong(18) > 0) {
                        series = findSeries(cursor.getLong(18));
                    }

                    author = null;
                    if (cursor.getLong(19) > 0) {
                        author = findAuthor(cursor.getInt(19));
                    }

                    books.add(new Book(cursor.getLong(0), cursor.getString(1), cursor.getString(2), cursor.getString(3),
                            cursor.getString(4), cursor.getInt(5), cursor.getString(6), cursor.getString(7), cursor.getString(8),
                            cursor.getString(9), cursor.getString(10), cursor.getFloat(11), (cursor.getInt(12) == 1),
                            cursor.getString(13), cursor.getString(14), cursor.getString(15), cursor.getInt(16), cursor.getInt(17),
                            series, author));
                } while (cursor.moveToNext());
            }
        } finally {
            cursor.close();
        }

        return books;
    }

}