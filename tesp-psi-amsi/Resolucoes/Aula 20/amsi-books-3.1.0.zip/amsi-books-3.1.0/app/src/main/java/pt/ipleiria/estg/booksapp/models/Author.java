package pt.ipleiria.estg.booksapp.models;

public class Author {

    private long id;
    private String name;
    private String biography;
    private String url;
    private String photo;
    private String surname;

    public Author(long id, String name, String surname, String biography, String url, String photo) {
        this.id = id;
        this.name = name;
        this.biography = biography;
        this.url = url;
        this.photo = photo;
        this.surname = surname;
    }

    public Author() {
        this(0, null, null, null, null, null);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBiography() {
        return biography;
    }

    public void setBiography(String biography) {
        this.biography = biography;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        final Author other = (Author) obj;
        return other.id == this.id;
    }
}
