package pt.ipleiria.estg.booksapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.Spinner;

import pt.ipleiria.estg.booksapp.fragments.AuthorsFragment;
import pt.ipleiria.estg.booksapp.fragments.BooksFragment;
import pt.ipleiria.estg.booksapp.fragments.GalleryFragment;
import pt.ipleiria.estg.booksapp.fragments.SeriesFragment;
import pt.ipleiria.estg.booksapp.models.Author;
import pt.ipleiria.estg.booksapp.models.Book;
import pt.ipleiria.estg.booksapp.models.Series;

public class Books extends AppCompatActivity implements BooksFragment.BookFragmentActionListener,
        SeriesFragment.SeriesFragmentActionListener, AuthorsFragment.AuthorFragmentActionListener {

    private Toolbar toolbar;
    private DrawerLayout drawer;
    private NavigationView nav;
    private ActionBarDrawerToggle toggle;
    private FragmentManager fragmentManager;
    //
    private GalleryFragment galleryFragment;
    private BooksFragment booksFragment;
    private AuthorsFragment authorsFragment;
    private SeriesFragment seriesFragment;
    //
    private AlertDialog settingsDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ac_books);

        fragmentManager = getSupportFragmentManager();

        toolbar = (Toolbar) findViewById(R.id.tb_main_toolbar);
        setSupportActionBar(toolbar);

        drawer = (DrawerLayout) findViewById(R.id.dl_main_drawer);
        toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navdrawer_open, R.string.navdrawer_close);

        drawer.addDrawerListener(toggle);
        toggle.syncState();

        nav = (NavigationView) findViewById(R.id.nv_main_navigation);
        nav.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                Fragment current = null;
                switch (id) {
                    case R.id.navmi_authors:
                        if (authorsFragment == null) {
                            authorsFragment = new AuthorsFragment();
                        }

                        current = authorsFragment;
                        toolbar.setTitle(R.string.fg_authors_title);
                        nav.setCheckedItem(R.id.navmi_authors);
                        break;
                    case R.id.navmi_export:
                        //TODO: ...
                        nav.setCheckedItem(R.id.navmi_export);
                        break;
                    case R.id.navmi_gallery:
                        if (galleryFragment == null) {
                            galleryFragment = new GalleryFragment();
                        }

                        current = galleryFragment;
                        toolbar.setTitle(R.string.fg_gallery_title);
                        nav.setCheckedItem(R.id.navmi_gallery);
                        break;
                    case R.id.navmi_series:
                        if (seriesFragment == null) {
                            seriesFragment = new SeriesFragment();
                        }

                        current = seriesFragment;
                        toolbar.setTitle(R.string.fg_series_title);
                        nav.setCheckedItem(R.id.navmi_series);
                        break;
                    case R.id.navmi_settings:
                        if (settingsDialog == null) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(Books.this);
                            builder.setTitle(R.string.dlg_settings_title)
                                    .setView(R.layout.dlg_settings)
                                    .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            //TODO: ...
                                        }
                                    })
                                    .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            //TODO: ...
                                        }
                                    });

                            settingsDialog = builder.create();
                        }
                        settingsDialog.show();
                        break;
                    default:
                        if (booksFragment == null) {
                            booksFragment = new BooksFragment();
                        }

                        current = booksFragment;

                        toolbar.setTitle(R.string.fg_books_title);
                        nav.setCheckedItem(R.id.navmi_books);
                }

                if (current != null) {
                    FragmentTransaction transaction = fragmentManager.beginTransaction();
                    transaction.replace(R.id.main_content_placeholder, current);
                    transaction.commit();
                }

                drawer.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        initDefaultState();
    }

    private void initDefaultState() {
        if (booksFragment == null) {
            booksFragment = new BooksFragment();
        }

        toolbar.setTitle(R.string.fg_books_title);

        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.main_content_placeholder, booksFragment);
        transaction.commit();

        nav.setCheckedItem(R.id.navmi_books);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if(booksFragment != null) {
            booksFragment.reloadData();
        }

        if(seriesFragment != null) {
            seriesFragment.reloadData();
        }

        if(authorsFragment != null) {
            authorsFragment.reloadData();
        }
    }

    @Override
    public void creatingNewBook() {
        startActivity(new Intent("pt.ipleiria.estg.booksapp.BOOKDETAILS"));
    }

    @Override
    public void bookSelected(Book book) {
        Intent intent = new Intent("pt.ipleiria.estg.booksapp.BOOKDETAILS");
        intent.putExtra("bookId", book.getId());

        startActivity(intent);
    }

    @Override
    public void creatingNewAuthor() {
        startActivity(new Intent("pt.ipleiria.estg.booksapp.AUTHORDETAILS"));
    }

    @Override
    public void authorSelected(Author author) {
        Intent intent = new Intent("pt.ipleiria.estg.booksapp.AUTHORDETAILS");
        intent.putExtra("authorId", author.getId());

        startActivity(intent);
    }

    @Override
    public void creatingNewSeries() {
        startActivity(new Intent("pt.ipleiria.estg.booksapp.SERIESDETAILS"));
    }

    @Override
    public void seriesSelected(Series series) {
        Intent intent = new Intent("pt.ipleiria.estg.booksapp.SERIESDETAILS");
        intent.putExtra("seriesId", series.getId());

        startActivity(intent);
    }
}
