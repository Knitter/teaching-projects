package pt.ipleiria.estg.booksapp.models;

public class Series {
    private long id;
    private String name;
    private int bookCount;
    private int ownCount;
    private boolean finished;

    public Series(long id, String name, int bookCount, int ownCount, boolean finished) {
        this.id = id;
        this.name = name;
        this.bookCount = bookCount;
        this.ownCount = ownCount;
        this.finished = finished;
    }

    public Series() {
        this(0, null, 0, 0, false);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getBookCount() {
        return bookCount;
    }

    public void setBookCount(int bookCount) {
        this.bookCount = bookCount;
    }

    public int getOwnCount() {
        return ownCount;
    }

    public void setOwnCount(int ownCount) {
        this.ownCount = ownCount;
    }

    public boolean isFinished() {
        return finished;
    }

    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        final Series other = (Series) obj;
        return other.id == this.id;
    }
}
