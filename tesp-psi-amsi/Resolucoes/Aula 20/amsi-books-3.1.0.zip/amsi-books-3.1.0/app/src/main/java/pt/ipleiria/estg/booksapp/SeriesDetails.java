package pt.ipleiria.estg.booksapp;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

import pt.ipleiria.estg.booksapp.db.LocalCache;
import pt.ipleiria.estg.booksapp.models.Series;

public class SeriesDetails extends AppCompatActivity {

    private Series series;
    private LocalCache db;
    //
    private TextInputLayout tlSeriesName;
    private TextView etSeriesName;
    private TextView etSeriesBookCount;
    private TextView etSeriesOwnCount;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ac_seriesdetails);

        db = new LocalCache(this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.tb_seriesdetails_toolbar);
        setSupportActionBar(toolbar);

        SeriesFieldValidator validator = new SeriesFieldValidator();

        tlSeriesName = (TextInputLayout) findViewById(R.id.tl_series_name);
        etSeriesName = (TextView) findViewById(R.id.et_series_name);
        etSeriesName.addTextChangedListener(validator);

        etSeriesBookCount = (TextView) findViewById(R.id.et_series_bookcount);
        etSeriesOwnCount = (TextView) findViewById(R.id.et_series_owncount);

        etSeriesName.setText("");
        etSeriesBookCount.setText("");
        etSeriesOwnCount.setText("");

        long seriesId = getIntent().getLongExtra("seriesId", -1);
        if (seriesId > -1) {
            series = db.findSeries(seriesId);

            etSeriesName.setText(series.getName());
            if (series.getBookCount() > 0) {
                etSeriesBookCount.setText("" + series.getBookCount());
            }

            if (series.getOwnCount() > 0) {
                etSeriesOwnCount.setText("" + series.getOwnCount());
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu_save, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.mi_save_option) {
            saveSeriesDetails(false);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void saveSeriesDetails(boolean back) {
        final View view = getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

        if (back && series == null && etSeriesName.getText().toString().trim().isEmpty()) {
            return;
        }

        if (series == null) {
            series = new Series();
        }

        series.setName(etSeriesName.getText().toString().trim());
        String val = etSeriesOwnCount.getText().toString().trim();

        series.setBookCount(0);
        if (!val.isEmpty()) {
            series.setBookCount(Integer.valueOf(val));
        }

        series.setOwnCount(0);
        val = etSeriesOwnCount.getText().toString().trim();
        if (!val.isEmpty()) {
            series.setOwnCount(Integer.valueOf(val));
        }

        boolean saved = db.save(series);

        if (!back) {
            if (saved) {
                Snackbar.make(findViewById(R.id.cl_ac_seriesdetails_root), R.string.ok_msg_seriesdetails_save, Snackbar.LENGTH_SHORT).show();
            } else {
                Snackbar.make(findViewById(R.id.cl_ac_seriesdetails_root), R.string.err_msg_seriesdetails_save, Snackbar.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onPause() {
        saveSeriesDetails(true);

        super.onPause();
    }

    @Override
    protected void onResume() {
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        super.onResume();
    }

    private class SeriesFieldValidator implements TextWatcher {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            final View v = getCurrentFocus();
            if (v != null) {
                final String value = ((TextView) v).getText().toString().trim();

                if (v.getId() == R.id.et_series_name) {
                    if (value.isEmpty()) {
                        tlSeriesName.setError(getString(R.string.err_msg_series_name));
                        if (etSeriesName.requestFocus()) {
                            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                        }

                        return;
                    }

                    tlSeriesName.setErrorEnabled(false);
                }
            }
        }
    }
}
