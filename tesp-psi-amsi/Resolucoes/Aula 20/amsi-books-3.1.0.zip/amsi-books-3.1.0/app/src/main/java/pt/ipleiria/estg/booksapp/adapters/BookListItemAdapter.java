package pt.ipleiria.estg.booksapp.adapters;

import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import pt.ipleiria.estg.booksapp.R;
import pt.ipleiria.estg.booksapp.models.Book;

public class BookListItemAdapter extends BaseAdapter {

    private Context context;
    private List<Book> books;
    private LayoutInflater inflater;
    private BitmapFactory.Options options;
    private int targetWidth = 0;
    private int targetHeight = 0;

    public BookListItemAdapter(Context context, List<Book> books) {
        this.context = context;
        this.books = books;

        options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        options.inJustDecodeBounds = false;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return (books != null ? books.size() : 0);
    }

    @Override
    public Object getItem(int position) {
        return books.get(position);
    }

    @Override
    public long getItemId(int position) {
        return books.get(position).getId();
    }

    @Override
    public View getView(int position, View reusedView, ViewGroup parent) {

        if (inflater == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if (reusedView == null) {
            reusedView = inflater.inflate(R.layout.li_book, null);
        }

        Book current = books.get(position);

        ((TextView) reusedView.findViewById(R.id.tv_book_title_item)).setText(current.getTitle());
        ((TextView) reusedView.findViewById(R.id.tv_book_author_item)).setText(current.getAuthor() != null ?
                current.getAuthor().getName() : "");

        ((TextView) reusedView.findViewById(R.id.tv_book_series_item)).setText(current.getSeries() != null ?
                current.getSeries().getName() : "");

        ImageView cover = (ImageView) reusedView.findViewById(R.id.iv_book_cover_item);
        if (targetWidth == 0 || targetHeight == 0) {
            targetWidth = cover.getWidth();
            targetHeight = cover.getHeight();
        }

        String filepath = current.getCover();
        if(filepath != null && !filepath.isEmpty()) {
            BitmapFactory.decodeFile(filepath, options);
            final int width = options.outWidth;
            final int height = options.outHeight;
            final int scaleFactor = Math.min(width / targetWidth, height / targetHeight);
            options.inSampleSize = scaleFactor;
            //options.inBitmap = cacheBitmap;

            cover.setImageBitmap(BitmapFactory.decodeFile(filepath, options));
        }

        return reusedView;
    }

}
