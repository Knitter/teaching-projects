package pt.ipleiria.estg.booksapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import pt.ipleiria.estg.booksapp.R;
import pt.ipleiria.estg.booksapp.models.Author;

public class AuthorListItemAdapter extends BaseAdapter {

    private Context context;
    private List<Author> authors;
    private LayoutInflater inflater;

    public AuthorListItemAdapter(Context context, List<Author> authors) {
        this.context = context;
        this.authors = authors;
    }

    public void setAuthors(List<Author> authors) {
        this.authors = authors;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return (authors != null ? authors.size() : 0);
    }

    @Override
    public Object getItem(int position) {
        return authors.get(position);
    }

    @Override
    public long getItemId(int position) {
        return authors.get(position).getId();
    }

    @Override
    public View getView(int position, View reusedView, ViewGroup parent) {

        if (inflater == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if (reusedView == null) {
            reusedView = inflater.inflate(R.layout.li_author, null);
        }

        Author current = authors.get(position);
        ((TextView) reusedView.findViewById(R.id.tv_author_name_item)).setText(current.getName() + " " + current.getSurname());
        return reusedView;
    }

}
