package pt.ipleiria.estg.booksapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import pt.ipleiria.estg.booksapp.R;
import pt.ipleiria.estg.booksapp.models.Series;

public class SeriesListItemAdapter extends BaseAdapter {

    private Context context;
    private List<Series> series;
    private LayoutInflater inflater;

    public SeriesListItemAdapter(Context context, List<Series> series) {
        this.context = context;
        this.series = series;
    }

    public void setSeries(List<Series> series) {
        this.series = series;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return (series != null ? series.size() : 0);
    }

    @Override
    public Object getItem(int position) {
        return series.get(position);
    }

    @Override
    public long getItemId(int position) {
        return series.get(position).getId();
    }

    @Override
    public View getView(int position, View reusedView, ViewGroup parent) {

        if (inflater == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if (reusedView == null) {
            reusedView = inflater.inflate(R.layout.li_series, null);
        }

        ((TextView) reusedView.findViewById(R.id.tv_series_name_item)).setText(series.get(position).getName());
        return reusedView;
    }

}
